---
document: Official UX Guidelines
product_definition: v2.0.0
status: OFFICIAL_SOURCE_OF_TRUTH
run_id: run_product_definition_20260801T144500Z
created_at: 2026-08-01T14:46:45Z
supersedes_candidate: ai-os/artifacts/product-strategy/runs/run_product_strategy_20260801T140000Z/
does_not_overwrite_spec_v1: true
---

# Official UX Guidelines

Calm adult voice · One primary CTA · Teach real≠virtual on Plan · Empty/loading/error patterns · WCAG-oriented contrast/focus · Sparse celebration motion (ritual/goal/EMI).
