# Artifact index (soft) — Template

> Never invent missing information · Never mutate sources · Structured findings only

## Entries

| validation_id | target | rule | result | severity | evidence | recommendation | confidence | unknowns |
|---------------|--------|------|--------|----------|----------|----------------|------------|----------|
| | | | | | | | | |

## Traceability

| source_artifact | feature | business_rule | requirement | architecture | knowledge |
|-----------------|---------|---------------|-------------|--------------|-----------|
| | | | | | |
