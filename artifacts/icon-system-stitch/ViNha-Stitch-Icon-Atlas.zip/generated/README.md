# ViNha Stitch icon atlas

Stitch generated 13 contact sheets covering the 271 semantic icon entries in [`../DESIGN.md`](../DESIGN.md). Open `index.html` to browse the complete set, or open any numbered sheet directly. Each sheet contains inline SVG artwork and 24 px / 16 px examples.

The source Stitch project is [ViNha Mobile Finance Icon System](https://stitch.withgoogle.com/projects/16826760243481546078). Stitch MCP saved all 13 screens, but the project canvas currently lists only some of them. This export preserves every generated sheet together.

These are design concepts for review. App integration should use the existing `AppIcon` and Hugeicons system described in `DESIGN.md`.
